﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TrabajoFinal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 1. Crear la instancia de Form2
            Form2 formulario2 = new Form2();

            // 2. Obligar a Form2 a usar la posición que le daremos manualmente
            formulario2.StartPosition = FormStartPosition.Manual;

            // 3. Copiar la ubicación exacta de Form1 a Form2
            formulario2.Location = this.Location;

            // Opcional: Si quieres que además mantenga exactamente el mismo tamaño
            formulario2.Size = this.Size;

            // 4. Ocultar Form1 y mostrar Form2
            this.Hide();
            formulario2.Show();

            // 5. Cerrar la aplicación por completo al salir de Form2
            formulario2.FormClosed += (s, args) => Application.Exit();

        }
    }
}
