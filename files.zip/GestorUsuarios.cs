using System.Security.Cryptography;
using System.Text;

namespace SistemaLogin;

public class GestorUsuarios
{
    private readonly List<Usuario> _usuarios = new();
    private readonly string _rutaArchivo;

    public GestorUsuarios()
    {
        _rutaArchivo = Path.Combine(AppContext.BaseDirectory, "usuarios.csv");
        Cargar();
    }

    public IReadOnlyList<Usuario> Usuarios => _usuarios;

    // ---------- Persistencia ----------

    private void Cargar()
    {
        try
        {
            if (!File.Exists(_rutaArchivo))
            {
                // Primera ejecución: se crea un profesor por defecto
                _usuarios.Add(new Usuario("profesor", Hashear("1234"), TipoAcceso.Profesor));
                Guardar();
                return;
            }

            foreach (string linea in File.ReadAllLines(_rutaArchivo))
            {
                if (string.IsNullOrWhiteSpace(linea)) continue;
                _usuarios.Add(Usuario.DesdeLinea(linea));
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("No se pudo leer el archivo de usuarios: " + ex.Message,
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void Guardar()
    {
        try
        {
            List<string> lineas = _usuarios.Select(u => u.ALinea()).ToList();
            File.WriteAllLines(_rutaArchivo, lineas);
        }
        catch (Exception ex)
        {
            MessageBox.Show("No se pudo guardar el archivo de usuarios: " + ex.Message,
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    // ---------- Operaciones ----------

    public bool Existe(string nombre)
    {
        return _usuarios.Any(u => u.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase));
    }

    public bool Registrar(string nombre, string password, TipoAcceso tipo)
    {
        if (Existe(nombre)) return false;

        _usuarios.Add(new Usuario(nombre, Hashear(password), tipo));
        Guardar();
        return true;
    }

    // Devuelve el usuario si nombre, contraseña y tipo coinciden; si no, null
    public Usuario? Validar(string nombre, string password, TipoAcceso tipo)
    {
        string hash = Hashear(password);
        return _usuarios.FirstOrDefault(u =>
            u.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase) &&
            u.PasswordHash == hash &&
            u.Tipo == tipo);
    }

    // La contraseña no se guarda en texto plano
    private static string Hashear(string texto)
    {
        byte[] bytes = SHA256.HashData(Encoding.UTF8.GetBytes(texto));
        return Convert.ToHexString(bytes);
    }
}
