namespace SistemaLogin;

// Formulario de inicio de sesión; se adapta según el tipo elegido
public class FormLogin : Form
{
    private readonly TipoAcceso _tipo;
    private readonly GestorUsuarios _gestor;

    private readonly TextBox txtUsuario = new();
    private readonly TextBox txtPassword = new();

    public FormLogin(TipoAcceso tipo, GestorUsuarios gestor)
    {
        _tipo = tipo;
        _gestor = gestor;

        Text = $"Inicio de sesión - {_tipo}";
        ClientSize = new Size(340, 260);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        AcceptButton = null;

        var lblTitulo = new Label
        {
            Text = $"Acceso de {_tipo}",
            Font = new Font("Segoe UI", 13, FontStyle.Bold),
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Location = new Point(10, 15),
            Size = new Size(320, 35)
        };

        var lblUsuario = new Label { Text = "Usuario:", Location = new Point(30, 70), AutoSize = true };
        txtUsuario.Location = new Point(30, 92);
        txtUsuario.Size = new Size(280, 25);

        var lblPassword = new Label { Text = "Contraseña:", Location = new Point(30, 128), AutoSize = true };
        txtPassword.Location = new Point(30, 150);
        txtPassword.Size = new Size(280, 25);
        txtPassword.UseSystemPasswordChar = true;

        var btnIngresar = new Button
        {
            Text = "Ingresar",
            Location = new Point(30, 195),
            Size = new Size(130, 35)
        };
        btnIngresar.Click += BtnIngresar_Click;
        AcceptButton = btnIngresar; // Enter = ingresar

        var btnRegistrar = new Button
        {
            Text = "Registrarse",
            Location = new Point(180, 195),
            Size = new Size(130, 35),
            // Solo los estudiantes pueden crearse una cuenta solos
            Enabled = _tipo == TipoAcceso.Estudiante
        };
        btnRegistrar.Click += BtnRegistrar_Click;

        Controls.AddRange(new Control[]
        {
            lblTitulo, lblUsuario, txtUsuario, lblPassword, txtPassword, btnIngresar, btnRegistrar
        });
    }

    private void BtnIngresar_Click(object? sender, EventArgs e)
    {
        string nombre = txtUsuario.Text.Trim();
        string password = txtPassword.Text;

        // Validación de datos
        if (nombre == "" || password == "")
        {
            MessageBox.Show("Completá usuario y contraseña.", "Datos incompletos",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        Usuario? usuario = _gestor.Validar(nombre, password, _tipo);

        if (usuario == null)
        {
            MessageBox.Show("Usuario o contraseña incorrectos (o no sos de este tipo de usuario).",
                "Error de acceso", MessageBoxButtons.OK, MessageBoxIcon.Error);
            txtPassword.Clear();
            txtPassword.Focus();
            return;
        }

        // Se abre un formulario distinto según el tipo de acceso
        Hide();
        Form panel = usuario.Tipo == TipoAcceso.Profesor
            ? new FormProfesor(usuario, _gestor)
            : new FormEstudiante(usuario);
        panel.ShowDialog();
        panel.Dispose();
        Close(); // vuelve a la pantalla de selección
    }

    private void BtnRegistrar_Click(object? sender, EventArgs e)
    {
        using var registro = new FormRegistro(_tipo, _gestor);
        registro.ShowDialog();
    }
}
