namespace SistemaLogin;

// Panel con permisos de Profesor (acceso ampliado: puede ver todos los usuarios)
public class FormProfesor : Form
{
    public FormProfesor(Usuario usuario, GestorUsuarios gestor)
    {
        Text = "Panel del Profesor";
        ClientSize = new Size(460, 360);
        StartPosition = FormStartPosition.CenterScreen;

        var lblBienvenida = new Label
        {
            Text = $"Bienvenido/a, profesor/a {usuario.Nombre}",
            Font = new Font("Segoe UI", 13, FontStyle.Bold),
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Dock = DockStyle.Top,
            Height = 50
        };

        var lblInfo = new Label
        {
            Text = "Usuarios registrados en el sistema:",
            AutoSize = false,
            Dock = DockStyle.Top,
            Height = 25,
            Padding = new Padding(10, 0, 0, 0)
        };

        // Grilla: solo se muestran nombre y tipo (nunca la contraseña)
        var grilla = new DataGridView
        {
            Dock = DockStyle.Fill,
            ReadOnly = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            RowHeadersVisible = false
        };
        grilla.DataSource = gestor.Usuarios
            .Select(u => new { Usuario = u.Nombre, Acceso = u.Tipo.ToString() })
            .ToList();

        var btnSalir = new Button
        {
            Text = "Cerrar sesión",
            Dock = DockStyle.Bottom,
            Height = 40
        };
        btnSalir.Click += (s, e) => Close();

        // El orden importa: Fill primero, luego los que se anclan a los bordes
        Controls.Add(grilla);
        Controls.Add(btnSalir);
        Controls.Add(lblInfo);
        Controls.Add(lblBienvenida);
    }
}
