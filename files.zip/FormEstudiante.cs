namespace SistemaLogin;

// Panel con permisos de Estudiante (acceso limitado)
public class FormEstudiante : Form
{
    public FormEstudiante(Usuario usuario)
    {
        Text = "Panel del Estudiante";
        ClientSize = new Size(380, 220);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var lblBienvenida = new Label
        {
            Text = $"¡Bienvenido/a, {usuario.Nombre}!",
            Font = new Font("Segoe UI", 14, FontStyle.Bold),
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Location = new Point(10, 25),
            Size = new Size(360, 40)
        };

        var lblAcceso = new Label
        {
            Text = $"Tipo de acceso: {usuario.Tipo}\n\nPermisos: ver tus materias y tareas.",
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Location = new Point(10, 80),
            Size = new Size(360, 60)
        };

        var btnSalir = new Button
        {
            Text = "Cerrar sesión",
            Location = new Point(120, 160),
            Size = new Size(140, 35)
        };
        btnSalir.Click += (s, e) => Close();

        Controls.AddRange(new Control[] { lblBienvenida, lblAcceso, btnSalir });
    }
}
