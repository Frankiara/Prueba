namespace SistemaLogin;

public class FormRegistro : Form
{
    private readonly TipoAcceso _tipo;
    private readonly GestorUsuarios _gestor;

    private readonly TextBox txtUsuario = new();
    private readonly TextBox txtPassword = new();
    private readonly TextBox txtConfirmar = new();

    public FormRegistro(TipoAcceso tipo, GestorUsuarios gestor)
    {
        _tipo = tipo;
        _gestor = gestor;

        Text = $"Registro - {_tipo}";
        ClientSize = new Size(340, 300);
        StartPosition = FormStartPosition.CenterParent;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;

        var lblUsuario = new Label { Text = "Usuario:", Location = new Point(30, 20), AutoSize = true };
        txtUsuario.Location = new Point(30, 42);
        txtUsuario.Size = new Size(280, 25);

        var lblPassword = new Label { Text = "Contraseña:", Location = new Point(30, 80), AutoSize = true };
        txtPassword.Location = new Point(30, 102);
        txtPassword.Size = new Size(280, 25);
        txtPassword.UseSystemPasswordChar = true;

        var lblConfirmar = new Label { Text = "Repetir contraseña:", Location = new Point(30, 140), AutoSize = true };
        txtConfirmar.Location = new Point(30, 162);
        txtConfirmar.Size = new Size(280, 25);
        txtConfirmar.UseSystemPasswordChar = true;

        var btnCrear = new Button
        {
            Text = "Crear cuenta",
            Location = new Point(30, 215),
            Size = new Size(130, 35)
        };
        btnCrear.Click += BtnCrear_Click;
        AcceptButton = btnCrear;

        var btnCancelar = new Button
        {
            Text = "Cancelar",
            Location = new Point(180, 215),
            Size = new Size(130, 35),
            DialogResult = DialogResult.Cancel
        };
        CancelButton = btnCancelar;

        Controls.AddRange(new Control[]
        {
            lblUsuario, txtUsuario, lblPassword, txtPassword, lblConfirmar, txtConfirmar, btnCrear, btnCancelar
        });
    }

    private void BtnCrear_Click(object? sender, EventArgs e)
    {
        string nombre = txtUsuario.Text.Trim();
        string password = txtPassword.Text;

        if (nombre == "" || password == "")
        {
            MessageBox.Show("Completá todos los campos.", "Datos incompletos",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (nombre.Contains(';'))
        {
            MessageBox.Show("El usuario no puede contener el carácter ';'.", "Dato inválido",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (password.Length < 4)
        {
            MessageBox.Show("La contraseña debe tener al menos 4 caracteres.", "Dato inválido",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (password != txtConfirmar.Text)
        {
            MessageBox.Show("Las contraseñas no coinciden.", "Dato inválido",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (!_gestor.Registrar(nombre, password, _tipo))
        {
            MessageBox.Show("Ya existe un usuario con ese nombre.", "Usuario existente",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        MessageBox.Show("Cuenta creada correctamente. Ya podés iniciar sesión.", "Listo",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
        Close();
    }
}
