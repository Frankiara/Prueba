namespace SistemaLogin;

// Pantalla inicial: el usuario elige qué tipo de acceso tiene
public class FormSeleccion : Form
{
    private readonly GestorUsuarios _gestor = new();

    public FormSeleccion()
    {
        Text = "Sistema de acceso";
        ClientSize = new Size(320, 220);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;

        var lblTitulo = new Label
        {
            Text = "¿Qué tipo de usuario sos?",
            Font = new Font("Segoe UI", 13, FontStyle.Bold),
            AutoSize = false,
            TextAlign = ContentAlignment.MiddleCenter,
            Location = new Point(10, 20),
            Size = new Size(300, 35)
        };

        var btnEstudiante = new Button
        {
            Text = "Soy Estudiante",
            Location = new Point(60, 75),
            Size = new Size(200, 45)
        };
        btnEstudiante.Click += (s, e) => AbrirLogin(TipoAcceso.Estudiante);

        var btnProfesor = new Button
        {
            Text = "Soy Profesor",
            Location = new Point(60, 135),
            Size = new Size(200, 45)
        };
        btnProfesor.Click += (s, e) => AbrirLogin(TipoAcceso.Profesor);

        Controls.AddRange(new Control[] { lblTitulo, btnEstudiante, btnProfesor });
    }

    private void AbrirLogin(TipoAcceso tipo)
    {
        Hide();
        using var login = new FormLogin(tipo, _gestor);
        login.ShowDialog();
        Show();
    }
}
