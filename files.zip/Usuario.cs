namespace SistemaLogin;

public enum TipoAcceso
{
    Estudiante,
    Profesor
}

public class Usuario
{
    // Encapsulamiento: propiedades de solo lectura, se asignan por constructor
    public string Nombre { get; }
    public string PasswordHash { get; }
    public TipoAcceso Tipo { get; }

    public Usuario(string nombre, string passwordHash, TipoAcceso tipo)
    {
        Nombre = nombre;
        PasswordHash = passwordHash;
        Tipo = tipo;
    }

    // Formato de una línea del archivo: nombre;hash;tipo
    public string ALinea()
    {
        return $"{Nombre};{PasswordHash};{Tipo}";
    }

    // Reconstruye un Usuario a partir de una línea del archivo
    public static Usuario DesdeLinea(string linea)
    {
        string[] partes = linea.Split(';');
        if (partes.Length != 3)
            throw new FormatException("Línea con formato inválido: " + linea);

        TipoAcceso tipo = Enum.Parse<TipoAcceso>(partes[2]);
        return new Usuario(partes[0], partes[1], tipo);
    }
}
