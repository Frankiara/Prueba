﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Trabajo_Practico
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        Form2 hoja2 = new Form2();
        Form1 hoja1 = new Form1();
        private void Form1_Load(object sender, EventArgs e)
        {
            
            hoja2.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            hoja2.Visible = true ;
            hoja1.Visible = false;
            
        }
    }
}
