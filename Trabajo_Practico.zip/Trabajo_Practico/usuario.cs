﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Trabajo_Practico
{
    internal class Usuarioo
    {
        public enum TipoAcceso { Estudiante, Profesor }

        public class Usuario
        {
            public string Nombre="";
            public string PasswordHash="";
            public TipoAcceso Tipo;


            public Usuario(string nombre, string passwordHash, TipoAcceso tipo)
            {
                Nombre = nombre;
                PasswordHash = passwordHash;
                Tipo = tipo;
            }

            public string ALinea()
            {
                return $"{Nombre};{PasswordHash};{Tipo}";
            }

            public static Usuario DesdeLinea(string linea)
            {

                //Esto es lo de separar en partes para hacer lo contrario de antes

                string[] partes = linea.Split(';');
                if (partes.Length != 3)
                    throw new FormatException("Línea con formato inválido: " + linea);

                //.Parse hace que se convierta en string creo

                TipoAcceso tipo = Enum.Parse<TipoAcceso>(partes[2]);
                return new Usuario(partes[0], partes[1], tipo);
            }
        }
    }




    }
    
